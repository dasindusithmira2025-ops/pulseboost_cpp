import { RotateCcw, Archive, Settings as SettingsIcon, Clock } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';

const restorePoints = [
  {
    id: 1,
    name: 'Before startup optimization',
    created: '2026-05-11 10:17:15',
    relatedAction: 'Disabled 3 startup applications',
    type: 'System Restore Point',
    risk: 'low' as const,
    size: '2.4 GB',
  },
  {
    id: 2,
    name: 'Before registry tweaks',
    created: '2026-05-10 14:22:08',
    relatedAction: 'Modified power management settings',
    type: 'System Restore Point',
    risk: 'medium' as const,
    size: '2.1 GB',
  },
  {
    id: 3,
    name: 'Automatic daily backup',
    created: '2026-05-09 08:00:00',
    relatedAction: 'Scheduled backup',
    type: 'System Restore Point',
    risk: 'safe' as const,
    size: '2.3 GB',
  },
];

const quarantinedFiles = [
  {
    id: 1,
    filename: 'olddriver_v2.3.dll',
    path: 'C:\\Windows\\System32\\drivers',
    quarantinedAt: '2026-05-11 10:18:00',
    reason: 'Replaced with updated version',
    size: '124 KB',
  },
  {
    id: 2,
    filename: 'temp_cache_2024.dat',
    path: 'C:\\Users\\User\\AppData\\Local\\Temp',
    quarantinedAt: '2026-05-11 10:16:45',
    reason: 'Temporary file cleanup',
    size: '2.3 MB',
  },
];

const reversibleTweaks = [
  {
    id: 1,
    name: 'Visual effects optimization',
    appliedAt: '2026-05-11 10:18:30',
    category: 'Performance',
    canRevert: true,
  },
  {
    id: 2,
    name: 'Background app restrictions',
    appliedAt: '2026-05-10 15:30:12',
    category: 'Privacy',
    canRevert: true,
  },
];

export default function RestoreCenter() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h2>Restore Center</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Undo changes and restore previous system states
        </p>
      </div>

      {/* Warning Banner */}
      <div className="bg-risk-medium/10 border border-risk-medium/30 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <RotateCcw className="w-5 h-5 text-risk-medium flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-medium text-foreground mb-1">Restore Safety Notice</div>
            <div className="text-xs text-muted-foreground">
              Restoring to a previous state will undo all changes made since that point. Ensure you understand
              the implications before proceeding.
            </div>
          </div>
        </div>
      </div>

      {/* System Restore Points */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3>System Restore Points</h3>
          <button className="px-4 py-2 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-all text-sm">
            Create Manual Restore Point
          </button>
        </div>

        <div className="space-y-3">
          {restorePoints.map((point) => (
            <div key={point.id} className="bg-secondary/50 border border-border rounded-lg p-4 hover:border-primary/30 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="font-medium text-foreground mb-1">{point.name}</div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {point.created}
                    </div>
                    <div>Size: {point.size}</div>
                  </div>
                </div>
                <RiskBadge level={point.risk} size="sm" />
              </div>

              <div className="space-y-2 mb-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Related action</span>
                  <span className="text-foreground">{point.relatedAction}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Type</span>
                  <span className="text-foreground">{point.type}</span>
                </div>
              </div>

              <button className="w-full py-2 bg-risk-medium/10 text-risk-medium border border-risk-medium/30 rounded hover:bg-risk-medium/20 transition-all text-sm font-medium">
                Restore to This Point
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Quarantined Files */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Quarantined Files</h3>
            <span className="text-sm text-muted-foreground">{quarantinedFiles.length} items</span>
          </div>

          <div className="space-y-3">
            {quarantinedFiles.map((file) => (
              <div key={file.id} className="bg-secondary/50 border border-border rounded-lg p-4">
                <div className="flex items-start gap-3 mb-3">
                  <Archive className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-foreground mb-1 truncate">
                      {file.filename}
                    </div>
                    <div className="text-xs text-muted-foreground mb-2">
                      {file.quarantinedAt}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Reason: {file.reason}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button className="flex-1 px-3 py-1.5 bg-primary/10 text-primary rounded hover:bg-primary/20 transition-all text-xs">
                    Restore
                  </button>
                  <button className="flex-1 px-3 py-1.5 border border-border rounded hover:border-risk-high/30 hover:text-risk-high transition-all text-xs">
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Reversible Tweaks */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Reversible Tweaks</h3>
            <span className="text-sm text-muted-foreground">{reversibleTweaks.length} active</span>
          </div>

          <div className="space-y-3">
            {reversibleTweaks.map((tweak) => (
              <div key={tweak.id} className="bg-secondary/50 border border-border rounded-lg p-4">
                <div className="flex items-start gap-3 mb-3">
                  <SettingsIcon className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground mb-1">
                      {tweak.name}
                    </div>
                    <div className="text-xs text-muted-foreground mb-2">
                      Applied: {tweak.appliedAt}
                    </div>
                    <div className="inline-block px-2 py-0.5 bg-primary/10 text-primary rounded text-xs">
                      {tweak.category}
                    </div>
                  </div>
                </div>

                <button className="w-full px-3 py-1.5 border border-border rounded hover:border-primary/30 transition-all text-xs">
                  Revert Tweak
                </button>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-border">
            <div className="text-xs text-muted-foreground leading-relaxed">
              All configuration changes are tracked and can be reverted individually without affecting
              other optimizations.
            </div>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Restore Timeline</h3>
        <div className="space-y-3">
          {[...restorePoints].reverse().map((point, index) => (
            <div key={point.id} className="flex items-start gap-4">
              <div className="flex flex-col items-center">
                <div className="w-3 h-3 rounded-full bg-primary" />
                {index < restorePoints.length - 1 && (
                  <div className="w-0.5 h-12 bg-border" />
                )}
              </div>
              <div className="flex-1 pb-4">
                <div className="text-sm font-medium text-foreground">{point.name}</div>
                <div className="text-xs text-muted-foreground mt-1">{point.created}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
