import { Wifi, AlertTriangle, Activity, Globe, Signal } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';
import MetricCard from '../shared/MetricCard';

const networkMetrics = [
  {
    name: 'DNS Resolution',
    value: '12ms',
    status: 'good' as const,
    details: 'Primary DNS: 8.8.8.8, Secondary DNS: 8.8.4.4',
  },
  {
    name: 'Latency',
    value: '28ms',
    status: 'good' as const,
    details: 'Average ping to gateway',
  },
  {
    name: 'Packet Loss',
    value: '0%',
    status: 'good' as const,
    details: 'No packet loss detected',
  },
  {
    name: 'TCP Connections',
    value: '47',
    status: 'normal' as const,
    details: '12 established, 35 time_wait',
  },
];

const advancedActions = [
  {
    id: 1,
    name: 'Reset Network Stack',
    description: 'Reset TCP/IP stack, Winsock, and network adapters to default state',
    risk: 'high' as const,
    requiresReview: true,
    requiresBackup: true,
  },
  {
    id: 2,
    name: 'Flush DNS Cache',
    description: 'Clear DNS resolver cache to fix resolution issues',
    risk: 'safe' as const,
    requiresReview: false,
    requiresBackup: false,
  },
  {
    id: 3,
    name: 'Renew DHCP Lease',
    description: 'Release and renew IP address from DHCP server',
    risk: 'low' as const,
    requiresReview: false,
    requiresBackup: false,
  },
  {
    id: 4,
    name: 'Reset Firewall Rules',
    description: 'Reset Windows Firewall to default configuration',
    risk: 'high' as const,
    requiresReview: true,
    requiresBackup: true,
  },
];

export default function NetworkTools() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h2>Network Tools</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Advanced network diagnostics and troubleshooting
        </p>
      </div>

      {/* Warning Banner */}
      <div className="bg-risk-high/10 border border-risk-high/30 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-risk-high flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-medium text-foreground mb-1">Advanced Tools - Manual Review Required</div>
            <div className="text-xs text-muted-foreground">
              Network configuration changes can affect system connectivity and security. All high-risk actions
              require manual review, restore point creation, and cannot be executed without explicit confirmation.
            </div>
          </div>
        </div>
      </div>

      {/* Network Health */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Network Health Status</h3>
        <div className="grid grid-cols-4 gap-4">
          <MetricCard
            icon={Globe}
            title="DNS Resolution"
            value="12ms"
            subtitle="Excellent"
            trend="neutral"
          />
          <MetricCard
            icon={Activity}
            title="Latency"
            value="28ms"
            subtitle="Good connection"
            trend="neutral"
          />
          <MetricCard
            icon={Signal}
            title="Packet Loss"
            value="0%"
            subtitle="No issues"
            trend="neutral"
          />
          <MetricCard
            icon={Wifi}
            title="Active Connections"
            value="47"
            subtitle="Normal activity"
            trend="neutral"
          />
        </div>
      </div>

      {/* Network Details */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="mb-4">Network Configuration</h3>
          <div className="space-y-3">
            <div className="bg-secondary/50 border border-border rounded-lg p-3">
              <div className="text-xs text-muted-foreground mb-1">IP Address</div>
              <div className="text-sm font-mono text-foreground">192.168.1.105</div>
            </div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3">
              <div className="text-xs text-muted-foreground mb-1">Gateway</div>
              <div className="text-sm font-mono text-foreground">192.168.1.1</div>
            </div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3">
              <div className="text-xs text-muted-foreground mb-1">DNS Servers</div>
              <div className="text-sm font-mono text-foreground">8.8.8.8, 8.8.4.4</div>
            </div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3">
              <div className="text-xs text-muted-foreground mb-1">Adapter</div>
              <div className="text-sm text-foreground">Intel Wi-Fi 6 AX200</div>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="mb-4">Connection Quality</h3>
          <div className="space-y-4">
            {networkMetrics.map((metric, index) => (
              <div key={index} className="bg-secondary/50 border border-border rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-sm font-medium text-foreground">{metric.name}</div>
                  <div className="text-lg font-semibold text-primary">{metric.value}</div>
                </div>
                <div className="text-xs text-muted-foreground">{metric.details}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Advanced Network Actions */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="mb-4">
          <h3>Advanced Network Actions</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Use these tools to diagnose and fix network issues
          </p>
        </div>

        <div className="space-y-3">
          {advancedActions.map((action) => (
            <div
              key={action.id}
              className="bg-secondary/50 border border-border rounded-lg p-4"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="font-medium text-foreground mb-1">{action.name}</div>
                  <div className="text-sm text-muted-foreground">{action.description}</div>
                </div>
                <RiskBadge level={action.risk} size="sm" />
              </div>

              <div className="flex items-center gap-4 mb-3 text-xs text-muted-foreground">
                {action.requiresReview && (
                  <div className="flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-risk-medium" />
                    <span>Manual review required</span>
                  </div>
                )}
                {action.requiresBackup && (
                  <div className="flex items-center gap-1">
                    <Wifi className="w-3 h-3" />
                    <span>Backup required</span>
                  </div>
                )}
              </div>

              {action.risk === 'high' ? (
                <div className="bg-risk-high/10 border border-risk-high/30 rounded-lg p-3">
                  <div className="flex items-start gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-risk-high flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-medium text-risk-high mb-1">High Risk Action</div>
                      <div className="text-xs text-muted-foreground mb-3">
                        This action requires manual review and restore point creation. You will be prompted
                        to confirm before execution.
                      </div>
                    </div>
                  </div>
                  <button className="w-full py-2 bg-risk-high/20 text-risk-high border border-risk-high/30 rounded hover:bg-risk-high/30 transition-all text-sm font-medium">
                    Prepare Action (Manual Review)
                  </button>
                </div>
              ) : (
                <button className="w-full py-2 bg-primary/10 text-primary border border-primary/30 rounded hover:bg-primary/20 transition-all text-sm font-medium">
                  Execute Action
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Safe Actions */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Quick Network Diagnostics</h3>
        <div className="grid grid-cols-3 gap-4">
          <button className="flex flex-col items-center gap-3 p-6 bg-secondary/50 border border-border rounded-lg hover:border-primary/30 transition-all">
            <div className="p-3 rounded-lg bg-primary/10">
              <Activity className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-foreground mb-1">Test Connection</div>
              <div className="text-xs text-muted-foreground">Ping gateway and DNS</div>
            </div>
          </button>

          <button className="flex flex-col items-center gap-3 p-6 bg-secondary/50 border border-border rounded-lg hover:border-primary/30 transition-all">
            <div className="p-3 rounded-lg bg-primary/10">
              <Globe className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-foreground mb-1">DNS Lookup</div>
              <div className="text-xs text-muted-foreground">Test DNS resolution</div>
            </div>
          </button>

          <button className="flex flex-col items-center gap-3 p-6 bg-secondary/50 border border-border rounded-lg hover:border-primary/30 transition-all">
            <div className="p-3 rounded-lg bg-primary/10">
              <Signal className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-foreground mb-1">Signal Quality</div>
              <div className="text-xs text-muted-foreground">Check wireless strength</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
