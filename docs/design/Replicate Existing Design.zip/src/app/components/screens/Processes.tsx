import { useState } from 'react';
import { AlertTriangle, Sparkles, Search } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';

const processes = [
  {
    id: 1,
    name: 'chrome.exe',
    publisher: 'Google LLC',
    cpu: 12.4,
    memory: 1842,
    disk: 2.1,
    path: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    safetyStatus: 'safe' as const,
    aiExplanation: 'Chrome is using resources normally for 8 open tabs. Memory usage is typical for this browser with your current workload.',
  },
  {
    id: 2,
    name: 'MsMpEng.exe',
    publisher: 'Microsoft Corporation',
    cpu: 8.2,
    memory: 312,
    disk: 15.4,
    path: 'C:\\Program Files\\Windows Defender\\MsMpEng.exe',
    safetyStatus: 'safe' as const,
    aiExplanation: 'Windows Defender antivirus is performing a background scan. High disk usage is normal during scans and will complete automatically.',
  },
  {
    id: 3,
    name: 'Discord.exe',
    publisher: 'Discord Inc.',
    cpu: 2.1,
    memory: 428,
    disk: 0.2,
    path: 'C:\\Users\\User\\AppData\\Local\\Discord\\app-1.0.9015\\Discord.exe',
    safetyStatus: 'safe' as const,
    aiExplanation: 'Discord is running in the background with minimal resource usage. Safe to end if not needed.',
  },
  {
    id: 4,
    name: 'System',
    publisher: 'Microsoft Corporation',
    cpu: 1.8,
    memory: 124,
    disk: 0.5,
    path: 'System process',
    safetyStatus: 'high' as const,
    aiExplanation: 'Critical Windows system process. Ending this will cause system instability or crash. DO NOT terminate.',
  },
  {
    id: 5,
    name: 'node.exe',
    publisher: 'Node.js Foundation',
    cpu: 45.2,
    memory: 2140,
    disk: 8.2,
    path: 'C:\\Program Files\\nodejs\\node.exe',
    safetyStatus: 'medium' as const,
    aiExplanation: 'Node.js development server using significant CPU. High usage is expected during active development. Ending will stop your development server.',
  },
];

export default function Processes() {
  const [selectedProcess, setSelectedProcess] = useState(processes[0]);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="h-full flex">
      {/* Left Panel - Process Table */}
      <div className="flex-1 p-8 overflow-auto border-r border-border">
        <div className="mb-6">
          <h2>Processes</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Monitor and analyze system processes
          </p>
        </div>

        {/* Warning Banner */}
        <div className="bg-risk-high/10 border border-risk-high/30 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-risk-high flex-shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium text-foreground mb-1">Process Termination Warning</div>
              <div className="text-xs text-muted-foreground">
                Ending processes can cause data loss or system instability. Always review AI analysis and safety
                status before terminating any process.
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search processes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:border-primary transition-colors"
          />
        </div>

        {/* Process Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary/50 border-b border-border">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Name</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Publisher</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground">CPU %</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground">RAM (MB)</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground">Disk %</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Safety</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {processes.map((process) => (
                  <tr
                    key={process.id}
                    onClick={() => setSelectedProcess(process)}
                    className={`cursor-pointer transition-colors ${
                      selectedProcess.id === process.id
                        ? 'bg-primary/10'
                        : 'hover:bg-secondary/30'
                    }`}
                  >
                    <td className="px-4 py-3 text-sm text-foreground font-mono">{process.name}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{process.publisher}</td>
                    <td className="px-4 py-3 text-sm text-foreground text-right tabular-nums">
                      {process.cpu.toFixed(1)}
                    </td>
                    <td className="px-4 py-3 text-sm text-foreground text-right tabular-nums">
                      {process.memory.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-foreground text-right tabular-nums">
                      {process.disk.toFixed(1)}
                    </td>
                    <td className="px-4 py-3">
                      <RiskBadge
                        level={process.safetyStatus}
                        size="sm"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Panel - Process Details */}
      <div className="w-[480px] p-8 bg-card/50 backdrop-blur-sm overflow-auto">
        <div className="space-y-6">
          <div>
            <h3 className="mb-2">Process Details</h3>
            <div className="font-mono text-sm text-foreground">{selectedProcess.name}</div>
          </div>

          {/* Resource Usage */}
          <div className="bg-secondary/50 border border-border rounded-lg p-4">
            <div className="text-sm font-medium text-foreground mb-3">Resource Usage</div>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1 text-sm">
                  <span className="text-muted-foreground">CPU</span>
                  <span className="text-foreground font-semibold">{selectedProcess.cpu}%</span>
                </div>
                <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${Math.min(selectedProcess.cpu, 100)}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1 text-sm">
                  <span className="text-muted-foreground">Memory</span>
                  <span className="text-foreground font-semibold">{selectedProcess.memory} MB</span>
                </div>
                <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${Math.min((selectedProcess.memory / 16384) * 100, 100)}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1 text-sm">
                  <span className="text-muted-foreground">Disk I/O</span>
                  <span className="text-foreground font-semibold">{selectedProcess.disk}%</span>
                </div>
                <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${Math.min(selectedProcess.disk, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Process Information */}
          <div className="bg-secondary/50 border border-border rounded-lg p-4">
            <div className="text-sm font-medium text-foreground mb-3">Process Information</div>
            <div className="space-y-2 text-sm">
              <div className="flex items-start justify-between">
                <span className="text-muted-foreground">Publisher</span>
                <span className="text-foreground text-right">{selectedProcess.publisher}</span>
              </div>
              <div className="flex items-start justify-between">
                <span className="text-muted-foreground">Path</span>
                <span className="text-foreground text-right font-mono text-xs break-all max-w-[280px]">
                  {selectedProcess.path}
                </span>
              </div>
              <div className="flex items-start justify-between">
                <span className="text-muted-foreground">Safety Status</span>
                <RiskBadge level={selectedProcess.safetyStatus} size="sm" />
              </div>
            </div>
          </div>

          {/* AI Explanation */}
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-lg p-4">
            <div className="flex items-start gap-3 mb-3">
              <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-medium text-foreground mb-1">AI Analysis</div>
                <div className="text-xs text-muted-foreground">Why this process is using resources</div>
              </div>
            </div>
            <p className="text-sm text-foreground leading-relaxed">
              {selectedProcess.aiExplanation}
            </p>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <button className="w-full py-2.5 bg-primary/10 text-primary border border-primary/30 rounded-lg hover:bg-primary/20 transition-all text-sm font-medium">
              Analyze Process
            </button>

            {selectedProcess.safetyStatus === 'high' ? (
              <div className="bg-risk-high/10 border border-risk-high/30 rounded-lg p-4">
                <div className="flex items-start gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-risk-high flex-shrink-0 mt-0.5" />
                  <div className="text-sm font-medium text-risk-high">Critical System Process</div>
                </div>
                <p className="text-xs text-muted-foreground">
                  This is a critical Windows system process. Terminating it will cause system instability or crash.
                  Process termination is disabled for your safety.
                </p>
                <button
                  disabled
                  className="w-full mt-3 py-2.5 bg-muted text-muted-foreground rounded-lg cursor-not-allowed text-sm font-medium"
                >
                  End Process (Blocked)
                </button>
              </div>
            ) : (
              <button className="w-full py-2.5 bg-risk-high/10 text-risk-high border border-risk-high/30 rounded-lg hover:bg-risk-high/20 transition-all text-sm font-medium flex items-center justify-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                End Process (High Risk)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
