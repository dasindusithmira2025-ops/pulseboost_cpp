import { Sparkles, AlertTriangle, TrendingUp, Shield } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';

const messages = [
  {
    type: 'ai' as const,
    content: 'Safe scan completed. I analyzed your system and found several optimization opportunities.',
    timestamp: '10:24 AM',
  },
  {
    type: 'ai' as const,
    content: 'I found 4 low-risk cleanup opportunities and 2 advanced actions that require manual review. All recommendations have been validated through dry-run simulation.',
    timestamp: '10:24 AM',
  },
];

const recommendations = [
  {
    title: 'Disable unused Windows features',
    reason: 'Several Windows features are enabled but never used, consuming system resources',
    confidence: '95%',
    risk: 'low' as const,
    evidence: 'Feature usage tracking shows 0 interactions in past 90 days',
  },
  {
    title: 'Optimize startup sequence',
    reason: 'Multiple applications launch at startup with high impact on boot time',
    confidence: '98%',
    risk: 'safe' as const,
    evidence: 'Boot time analysis shows 8.2s delay from startup apps',
  },
  {
    title: 'Clean Windows update cache',
    reason: 'Windows update cache contains 3.2 GB of old installation files',
    confidence: '100%',
    risk: 'safe' as const,
    evidence: 'Files are older than 30 days and safely removable',
  },
  {
    title: 'Adjust power management settings',
    reason: 'Current power plan is not optimized for your usage pattern',
    confidence: '87%',
    risk: 'medium' as const,
    evidence: 'System usage analysis suggests balanced power plan modifications',
  },
];

export default function AIAdvisor() {
  return (
    <div className="h-full flex">
      {/* Left Panel - Chat Interface */}
      <div className="flex-1 flex flex-col p-8 border-r border-border">
        {/* Banner */}
        <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-medium text-foreground mb-1">AI Advisory Mode</div>
              <div className="text-xs text-muted-foreground">
                AI can recommend actions, but high-risk actions require your confirmation.
              </div>
            </div>
          </div>
        </div>

        <h2 className="mb-6">AI System Advisor</h2>

        {/* Messages */}
        <div className="flex-1 space-y-4 overflow-auto mb-6">
          {messages.map((message, index) => (
            <div key={index} className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1">
                <div className="bg-card border border-border rounded-lg p-4">
                  <p className="text-sm text-foreground leading-relaxed">{message.content}</p>
                </div>
                <div className="text-xs text-muted-foreground mt-1 ml-1">{message.timestamp}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Ask about your system or request specific optimizations..."
            className="flex-1 px-4 py-3 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:border-primary transition-colors"
          />
          <button className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all">
            Send
          </button>
        </div>
      </div>

      {/* Right Panel - Recommendations */}
      <div className="w-[480px] p-8 overflow-auto">
        <div className="mb-6">
          <h3>AI Recommendations</h3>
          <p className="text-sm text-muted-foreground mt-1">
            {recommendations.length} actions prepared
          </p>
        </div>

        <div className="space-y-4">
          {recommendations.map((rec, index) => (
            <div key={index} className="bg-card border border-border rounded-lg p-5 hover:border-primary/30 transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="font-medium text-foreground mb-1">{rec.title}</div>
                </div>
                <RiskBadge level={rec.risk} size="sm" />
              </div>

              <div className="space-y-3">
                {/* Reason */}
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Reason</div>
                  <div className="text-sm text-foreground">{rec.reason}</div>
                </div>

                {/* Evidence */}
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Evidence</div>
                  <div className="text-sm text-foreground bg-secondary/50 rounded p-2">
                    {rec.evidence}
                  </div>
                </div>

                {/* Confidence */}
                <div className="flex items-center justify-between">
                  <div className="text-xs text-muted-foreground">AI Confidence</div>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary"
                        style={{ width: rec.confidence }}
                      />
                    </div>
                    <span className="text-xs text-foreground font-medium">{rec.confidence}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-4 pt-4 border-t border-border">
                <button className="flex-1 px-4 py-2 bg-primary/10 text-primary rounded hover:bg-primary/20 transition-all text-sm">
                  Prepare Dry Run
                </button>
                <button className="px-4 py-2 border border-border rounded hover:border-primary/30 transition-all text-sm">
                  Dismiss
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Safety Notice */}
        <div className="mt-6 bg-muted/30 border border-border rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-4 h-4 text-risk-medium flex-shrink-0 mt-0.5" />
            <div className="text-xs text-muted-foreground leading-relaxed">
              All AI recommendations are verified through dry-run simulations. High-risk actions will
              require manual confirmation and restore point creation before execution.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
