import { Cpu, MemoryStick, HardDrive, Rocket, Shield, FileCheck, Radio } from 'lucide-react';
import MetricCard from '../shared/MetricCard';
import HealthScore from '../shared/HealthScore';
import RiskBadge from '../shared/RiskBadge';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const beforeAfterData = [
  { name: 'Mon', before: 85, after: 45 },
  { name: 'Tue', before: 88, after: 42 },
  { name: 'Wed', before: 90, after: 40 },
  { name: 'Thu', before: 87, after: 38 },
  { name: 'Fri', before: 92, after: 35 },
  { name: 'Sat', before: 89, after: 32 },
  { name: 'Today', before: 91, after: 28 },
];

const recommendedActions = [
  {
    title: 'Disable 3 high-impact startup apps',
    benefit: 'Improve boot time by ~8 seconds',
    risk: 'safe' as const,
  },
  {
    title: 'Clean temporary files (2.4 GB)',
    benefit: 'Free up storage space',
    risk: 'safe' as const,
  },
  {
    title: 'Optimize background services',
    benefit: 'Reduce memory pressure by 12%',
    risk: 'low' as const,
  },
];

export default function Overview() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Overview Dashboard</h2>
          <p className="text-sm text-muted-foreground mt-1">System health at a glance</p>
        </div>
        <button className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
          Run Safe Scan
        </button>
      </div>

      {/* Hero Card - PC Health Score */}
      <div className="bg-gradient-to-br from-card via-card to-primary/5 border border-border rounded-xl p-8">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="mb-2">PC Health Score</h3>
            <p className="text-muted-foreground mb-4">
              Your system is performing well. A few safe optimizations available.
            </p>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 rounded-full bg-risk-safe" />
                <span className="text-muted-foreground">92 optimization actions completed</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <div className="w-2 h-2 rounded-full bg-risk-low" />
                <span className="text-muted-foreground">3 safe actions recommended</span>
              </div>
            </div>
          </div>
          <HealthScore score={87} size="lg" />
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-4 gap-4">
        <MetricCard
          icon={Cpu}
          title="CPU Pressure"
          value="28%"
          subtitle="12% lower than yesterday"
          trend="down"
        />
        <MetricCard
          icon={MemoryStick}
          title="Memory Pressure"
          value="5.2 GB"
          subtitle="of 16 GB used"
          trend="neutral"
        />
        <MetricCard
          icon={HardDrive}
          title="Disk Usage"
          value="62%"
          subtitle="238 GB free"
          trend="neutral"
        />
        <MetricCard
          icon={Rocket}
          title="Startup Impact"
          value="8.2s"
          subtitle="4 apps enabled"
          trend="down"
        />
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Recommended Safe Actions */}
        <div className="col-span-2 bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Recommended Safe Actions</h3>
            <span className="text-sm text-muted-foreground">3 available</span>
          </div>
          <div className="space-y-3">
            {recommendedActions.map((action, index) => (
              <div
                key={index}
                className="bg-secondary/50 border border-border rounded-lg p-4 hover:border-primary/30 transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground mb-1">
                      {action.title}
                    </div>
                    <div className="text-xs text-muted-foreground">{action.benefit}</div>
                  </div>
                  <RiskBadge level={action.risk} size="sm" />
                </div>
                <div className="flex gap-2 mt-3">
                  <button className="text-xs px-3 py-1.5 bg-primary/10 text-primary rounded hover:bg-primary/20 transition-all">
                    Review
                  </button>
                  <button className="text-xs px-3 py-1.5 border border-border rounded hover:border-primary/30 transition-all">
                    Apply
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Safety Status */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="mb-4">Safety Status</h3>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-risk-safe/10">
                <Shield className="w-4 h-4 text-risk-safe" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium text-foreground">Restore Point Available</div>
                <div className="text-xs text-muted-foreground mt-0.5">Created 15 min ago</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-risk-safe/10">
                <FileCheck className="w-4 h-4 text-risk-safe" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium text-foreground">Audit Logging Enabled</div>
                <div className="text-xs text-muted-foreground mt-0.5">All actions tracked</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-risk-low/10">
                <Radio className="w-4 h-4 text-risk-low" />
              </div>
              <div className="flex-1">
                <div className="text-sm font-medium text-foreground">AI Advisory Mode</div>
                <div className="text-xs text-muted-foreground mt-0.5">Recommendations only</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Before / After Snapshot */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3>Before / After Snapshot</h3>
            <p className="text-sm text-muted-foreground mt-1">System resource usage over time</p>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-risk-high/50" />
              <span className="text-muted-foreground">Before</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-risk-safe" />
              <span className="text-muted-foreground">After</span>
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={beforeAfterData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis
              dataKey="name"
              stroke="#8b92a8"
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis stroke="#8b92a8" fontSize={12} tickLine={false} axisLine={false} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#13172b',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px',
              }}
            />
            <Area
              type="monotone"
              dataKey="before"
              stackId="1"
              stroke="#ff4757"
              fill="#ff4757"
              fillOpacity={0.3}
            />
            <Area
              type="monotone"
              dataKey="after"
              stackId="2"
              stroke="#00ff88"
              fill="#00ff88"
              fillOpacity={0.5}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* AI Summary Panel */}
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-lg p-6">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-lg bg-primary/20">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="mb-2">AI System Analysis</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Your PC is running well. I detected 3 startup applications with high boot impact that can be safely disabled,
              freeing approximately 8 seconds from your boot time. Additionally, 2.4 GB of temporary files are safe to remove.
              All recommended actions have passed dry-run validation and can be applied with one click.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
