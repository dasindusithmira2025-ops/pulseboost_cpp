import { Shield, Bell, Palette, Database, Lock, Info } from 'lucide-react';

const settingSections = [
  {
    title: 'AI & Safety',
    icon: Shield,
    settings: [
      {
        name: 'AI Mode',
        description: 'Control how AI processes system data',
        type: 'select' as const,
        value: 'local',
        options: ['Local only', 'Cloud optional', 'Disabled'],
      },
      {
        name: 'Require confirmation for medium risk actions',
        description: 'Show confirmation dialog before medium risk optimizations',
        type: 'toggle' as const,
        value: true,
      },
      {
        name: 'Require confirmation for high risk actions',
        description: 'Show confirmation dialog before high risk optimizations',
        type: 'toggle' as const,
        value: true,
      },
      {
        name: 'Auto-create restore points',
        description: 'Automatically create restore points before risky actions',
        type: 'toggle' as const,
        value: true,
      },
    ],
  },
  {
    title: 'Audit & Logging',
    icon: Database,
    settings: [
      {
        name: 'Enable audit logging',
        description: 'Log all system-changing actions for transparency',
        type: 'toggle' as const,
        value: true,
      },
      {
        name: 'Log retention period',
        description: 'How long to keep audit logs',
        type: 'select' as const,
        value: '90',
        options: ['30 days', '90 days', '180 days', '1 year', 'Forever'],
      },
      {
        name: 'Include technical details',
        description: 'Include JSON-formatted technical data in audit logs',
        type: 'toggle' as const,
        value: true,
      },
    ],
  },
  {
    title: 'Quarantine & Restore',
    icon: Database,
    settings: [
      {
        name: 'Quarantine duration',
        description: 'How long to keep files in quarantine before permanent deletion',
        type: 'select' as const,
        value: '30',
        options: ['7 days', '30 days', '60 days', '90 days', 'Manual only'],
      },
      {
        name: 'Restore point behavior',
        description: 'When to create system restore points',
        type: 'select' as const,
        value: 'before-risky',
        options: ['Before all actions', 'Before risky actions only', 'Manual only'],
      },
      {
        name: 'Keep restore points',
        description: 'Maximum number of restore points to maintain',
        type: 'select' as const,
        value: '5',
        options: ['3', '5', '10', '20'],
      },
    ],
  },
  {
    title: 'Privacy',
    icon: Lock,
    settings: [
      {
        name: 'Local telemetry only',
        description: 'Keep all diagnostic data on your device',
        type: 'toggle' as const,
        value: true,
      },
      {
        name: 'Anonymous usage statistics',
        description: 'Help improve PulseBoost AI with anonymous usage data',
        type: 'toggle' as const,
        value: false,
      },
      {
        name: 'Prevent silent system changes',
        description: 'Block any action that does not require explicit user confirmation',
        type: 'toggle' as const,
        value: true,
      },
    ],
  },
  {
    title: 'Appearance',
    icon: Palette,
    settings: [
      {
        name: 'Theme',
        description: 'Application color theme',
        type: 'select' as const,
        value: 'dark',
        options: ['Dark', 'Light', 'System'],
      },
      {
        name: 'Accent color',
        description: 'Primary accent color',
        type: 'select' as const,
        value: 'cyan',
        options: ['Electric Cyan', 'Blue', 'Purple', 'Green'],
      },
      {
        name: 'Reduce animations',
        description: 'Minimize UI animations for better performance',
        type: 'toggle' as const,
        value: false,
      },
    ],
  },
  {
    title: 'Notifications',
    icon: Bell,
    settings: [
      {
        name: 'Scan completion notifications',
        description: 'Notify when system scans complete',
        type: 'toggle' as const,
        value: true,
      },
      {
        name: 'High-risk action alerts',
        description: 'Alert before executing high-risk actions',
        type: 'toggle' as const,
        value: true,
      },
      {
        name: 'AI recommendations',
        description: 'Show notifications for new AI recommendations',
        type: 'toggle' as const,
        value: true,
      },
    ],
  },
];

export default function Settings() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h2>Settings</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Configure safety, privacy, and application preferences
        </p>
      </div>

      {/* Privacy Notice */}
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-medium text-foreground mb-1">Privacy & Transparency Commitment</div>
            <div className="text-xs text-muted-foreground">
              PulseBoost AI processes all data locally by default. We do not sell your data or make silent
              system changes. All actions require explicit user confirmation based on your safety settings.
            </div>
          </div>
        </div>
      </div>

      {/* Settings Sections */}
      {settingSections.map((section, sectionIndex) => (
        <div key={sectionIndex} className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <section.icon className="w-5 h-5 text-primary" />
            </div>
            <h3>{section.title}</h3>
          </div>

          <div className="space-y-4">
            {section.settings.map((setting, settingIndex) => (
              <div
                key={settingIndex}
                className="flex items-start justify-between py-4 border-b border-border last:border-0"
              >
                <div className="flex-1 pr-6">
                  <div className="text-sm font-medium text-foreground mb-1">{setting.name}</div>
                  <div className="text-xs text-muted-foreground">{setting.description}</div>
                </div>

                {setting.type === 'toggle' ? (
                  <div
                    className={`w-11 h-6 rounded-full relative transition-all cursor-pointer ${
                      setting.value ? 'bg-primary' : 'bg-muted'
                    }`}
                  >
                    <div
                      className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all ${
                        setting.value ? 'right-0.5' : 'left-0.5'
                      }`}
                    />
                  </div>
                ) : (
                  <select className="px-3 py-1.5 bg-input-background border border-border rounded text-sm focus:outline-none focus:border-primary transition-colors">
                    {setting.options?.map((option, optionIndex) => (
                      <option key={optionIndex} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* About Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 rounded-lg bg-primary/10">
            <Info className="w-5 h-5 text-primary" />
          </div>
          <h3>About PulseBoost AI</h3>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-muted-foreground">Version</span>
            <span className="text-sm text-foreground font-medium">2.5.0 Pro</span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-muted-foreground">Build</span>
            <span className="text-sm text-foreground font-mono">20260511.1842</span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-muted-foreground">License</span>
            <span className="text-sm text-foreground">Professional</span>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-border space-y-2">
          <button className="w-full py-2 bg-primary/10 text-primary border border-primary/30 rounded hover:bg-primary/20 transition-all text-sm">
            Check for Updates
          </button>
          <button className="w-full py-2 border border-border rounded hover:border-primary/30 transition-all text-sm">
            View Documentation
          </button>
          <button className="w-full py-2 border border-border rounded hover:border-primary/30 transition-all text-sm">
            Export Settings
          </button>
        </div>
      </div>

      {/* Reset Options */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Reset Options</h3>
        <div className="space-y-3">
          <button className="w-full py-2.5 bg-risk-medium/10 text-risk-medium border border-risk-medium/30 rounded hover:bg-risk-medium/20 transition-all text-sm font-medium">
            Reset All Settings to Default
          </button>
          <button className="w-full py-2.5 bg-risk-high/10 text-risk-high border border-risk-high/30 rounded hover:bg-risk-high/20 transition-all text-sm font-medium">
            Clear All Audit Logs
          </button>
        </div>
      </div>
    </div>
  );
}
