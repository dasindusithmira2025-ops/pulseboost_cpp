import { Download, TrendingDown, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const comparisonData = [
  {
    metric: 'Boot Time',
    before: 32,
    after: 18,
    unit: 'seconds'
  },
  {
    metric: 'Memory Usage',
    before: 68,
    after: 42,
    unit: '%'
  },
  {
    metric: 'Startup Apps',
    before: 12,
    after: 4,
    unit: 'apps'
  },
  {
    metric: 'Background Tasks',
    before: 87,
    after: 52,
    unit: 'processes'
  },
];

const storageData = [
  { name: 'System', before: 85, after: 82 },
  { name: 'Apps', before: 120, after: 118 },
  { name: 'Temp Files', before: 15, after: 2 },
  { name: 'Cache', before: 8, after: 1 },
  { name: 'Logs', before: 4, after: 1 },
];

const timeline = [
  { step: 'Scan', status: 'completed', time: '10:15 AM' },
  { step: 'Dry Run', status: 'completed', time: '10:16 AM' },
  { step: 'Restore Point', status: 'completed', time: '10:17 AM' },
  { step: 'Apply', status: 'completed', time: '10:18 AM' },
  { step: 'Verified Result', status: 'completed', time: '10:19 AM' },
];

export default function BeforeAfterProof() {
  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Before / After Proof Report</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Verified system improvements from optimization actions
          </p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-all">
          <Download className="w-4 h-4" />
          Export Report
        </button>
      </div>

      {/* Timeline */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-6">Optimization Timeline</h3>
        <div className="flex items-center justify-between relative">
          <div className="absolute top-4 left-0 right-0 h-0.5 bg-border" />
          <div className="absolute top-4 left-0 h-0.5 bg-primary transition-all" style={{ width: '100%' }} />

          {timeline.map((item, index) => (
            <div key={index} className="relative flex flex-col items-center z-10">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                item.status === 'completed' ? 'bg-primary' : 'bg-muted'
              }`}>
                <CheckCircle className="w-4 h-4 text-primary-foreground" />
              </div>
              <div className="mt-3 text-sm font-medium text-foreground text-center whitespace-nowrap">
                {item.step}
              </div>
              <div className="text-xs text-muted-foreground mt-1">{item.time}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Comparison Cards */}
      <div className="grid grid-cols-4 gap-4">
        {comparisonData.map((item, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-5">
            <div className="text-sm text-muted-foreground mb-3">{item.metric}</div>
            <div className="space-y-2">
              <div className="flex items-baseline gap-2">
                <span className="text-xs text-muted-foreground">Before:</span>
                <span className="text-lg text-risk-high">{item.before}</span>
                <span className="text-xs text-muted-foreground">{item.unit}</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-xs text-muted-foreground">After:</span>
                <span className="text-lg text-risk-safe font-semibold">{item.after}</span>
                <span className="text-xs text-muted-foreground">{item.unit}</span>
              </div>
              <div className="flex items-center gap-1 pt-2 border-t border-border">
                <TrendingDown className="w-3 h-3 text-risk-safe" />
                <span className="text-xs text-risk-safe">
                  {Math.round(((item.before - item.after) / item.before) * 100)}% improvement
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Storage Cleanup Chart */}
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="mb-4">
            <h3>Storage Analysis</h3>
            <p className="text-sm text-muted-foreground mt-1">Space recovered by category (GB)</p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={storageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis
                dataKey="name"
                stroke="#8b92a8"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis stroke="#8b92a8" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#13172b',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Bar dataKey="before" fill="#ff4757" radius={[4, 4, 0, 0]} />
              <Bar dataKey="after" fill="#00ff88" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Summary */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="mb-4">Improvement Summary</h3>
          <div className="space-y-4">
            <div className="bg-secondary/50 border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Boot Time Improvement</span>
                <span className="text-lg font-semibold text-risk-safe">-43%</span>
              </div>
              <div className="text-xs text-muted-foreground">From 32s to 18s</div>
            </div>

            <div className="bg-secondary/50 border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Memory Freed</span>
                <span className="text-lg font-semibold text-risk-safe">4.2 GB</span>
              </div>
              <div className="text-xs text-muted-foreground">38% memory pressure reduction</div>
            </div>

            <div className="bg-secondary/50 border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Storage Recovered</span>
                <span className="text-lg font-semibold text-risk-safe">13.4 GB</span>
              </div>
              <div className="text-xs text-muted-foreground">Temporary and cache files removed</div>
            </div>

            <div className="bg-secondary/50 border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-muted-foreground">Background Processes</span>
                <span className="text-lg font-semibold text-risk-safe">-40%</span>
              </div>
              <div className="text-xs text-muted-foreground">From 87 to 52 processes</div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-border">
            <div className="bg-gradient-to-r from-primary/10 to-transparent border border-primary/20 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-foreground mb-1">All Changes Verified</div>
                  <div className="text-xs text-muted-foreground">
                    System performance improvements confirmed through post-optimization benchmarks
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
