import { useState } from 'react';
import { Search, Filter, CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';

const auditEntries = [
  {
    id: 1,
    time: '2026-05-11 10:18:42',
    action: 'Disabled 3 startup applications',
    risk: 'safe' as const,
    result: 'success' as const,
    rollbackAvailable: true,
    userConfirmation: true,
    affectedPaths: ['HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'],
    details: {
      technical: {
        before: { startupApps: 12, bootTime: '32s' },
        after: { startupApps: 4, bootTime: '18s' },
      },
      explanation: 'Successfully disabled 3 high-impact startup applications: Discord, Spotify, and Steam. Boot time improved by 14 seconds.',
    },
  },
  {
    id: 2,
    time: '2026-05-11 10:17:15',
    action: 'Created system restore point',
    risk: 'safe' as const,
    result: 'success' as const,
    rollbackAvailable: false,
    userConfirmation: false,
    affectedPaths: ['System Protection'],
    details: {
      technical: {
        restorePointId: 'RP-2026-05-11-101715',
        size: '2.4 GB',
      },
      explanation: 'Automatic restore point created before applying optimization actions. Can be used to rollback all changes if needed.',
    },
  },
  {
    id: 3,
    time: '2026-05-11 10:16:30',
    action: 'Cleaned temporary browser cache',
    risk: 'safe' as const,
    result: 'success' as const,
    rollbackAvailable: false,
    userConfirmation: true,
    affectedPaths: [
      'C:\\Users\\User\\AppData\\Local\\Google\\Chrome\\Cache',
      'C:\\Users\\User\\AppData\\Local\\Microsoft\\Edge\\Cache',
    ],
    details: {
      technical: {
        filesRemoved: 1247,
        spaceRecovered: '2.1 GB',
      },
      explanation: 'Removed cached files from Chrome and Edge browsers. Bookmarks and passwords were not affected.',
    },
  },
  {
    id: 4,
    time: '2026-05-11 09:45:12',
    action: 'Dry-run: Disable Windows telemetry',
    risk: 'high' as const,
    result: 'simulated' as const,
    rollbackAvailable: true,
    userConfirmation: true,
    affectedPaths: ['DiagTrack service', 'dmwappushservice'],
    details: {
      technical: {
        servicesAffected: ['DiagTrack', 'dmwappushservice'],
        dryRunResult: 'passed',
      },
      explanation: 'Dry-run simulation completed successfully. Action requires manual confirmation and restore point before actual execution.',
    },
  },
];

export default function AuditLog() {
  const [selectedEntry, setSelectedEntry] = useState(auditEntries[0]);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="h-full flex">
      {/* Left Panel - Audit Table */}
      <div className="flex-1 p-8 overflow-auto border-r border-border">
        <div className="mb-6">
          <h2>Audit Log</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Complete transparency of all system actions
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex gap-3 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search audit log..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:border-primary transition-colors"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-secondary border border-border rounded-lg hover:border-primary/30 transition-all text-sm">
            <Filter className="w-4 h-4" />
            Filters
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-2 mb-4">
          {['Today', 'This Week', 'High Risk', 'Rollback Available', 'Failed Actions'].map((filter) => (
            <button
              key={filter}
              className="px-3 py-1.5 bg-secondary border border-border rounded-full text-xs hover:border-primary/30 transition-all"
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Audit Table */}
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-secondary/50 border-b border-border">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Time</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Action</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Risk</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Result</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Rollback</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Confirmed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {auditEntries.map((entry) => (
                  <tr
                    key={entry.id}
                    onClick={() => setSelectedEntry(entry)}
                    className={`cursor-pointer transition-colors ${
                      selectedEntry.id === entry.id
                        ? 'bg-primary/10'
                        : 'hover:bg-secondary/30'
                    }`}
                  >
                    <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">
                      {entry.time}
                    </td>
                    <td className="px-4 py-3 text-sm text-foreground">{entry.action}</td>
                    <td className="px-4 py-3">
                      <RiskBadge level={entry.risk} size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      {entry.result === 'success' && (
                        <span className="inline-flex items-center gap-1 text-xs text-risk-safe">
                          <CheckCircle className="w-3 h-3" />
                          Success
                        </span>
                      )}
                      {entry.result === 'simulated' && (
                        <span className="inline-flex items-center gap-1 text-xs text-risk-low">
                          <CheckCircle className="w-3 h-3" />
                          Simulated
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {entry.rollbackAvailable ? (
                        <span className="inline-flex items-center gap-1 text-xs text-risk-safe">
                          <RotateCcw className="w-3 h-3" />
                          Available
                        </span>
                      ) : (
                        <span className="text-xs text-muted-foreground">N/A</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {entry.userConfirmation ? (
                        <CheckCircle className="w-4 h-4 text-risk-safe" />
                      ) : (
                        <span className="text-xs text-muted-foreground">Auto</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Panel - Detail Drawer */}
      <div className="w-[480px] p-8 bg-card/50 backdrop-blur-sm overflow-auto">
        <div className="space-y-6">
          <div>
            <div className="flex items-start justify-between mb-2">
              <h3>Audit Entry Details</h3>
              <RiskBadge level={selectedEntry.risk} />
            </div>
            <div className="text-sm text-muted-foreground">{selectedEntry.time}</div>
          </div>

          {/* Action */}
          <div>
            <div className="text-sm font-medium text-foreground mb-2">Action</div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3 text-sm text-foreground">
              {selectedEntry.action}
            </div>
          </div>

          {/* Human-Readable Explanation */}
          <div>
            <div className="text-sm font-medium text-foreground mb-2">Explanation</div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3 text-sm text-muted-foreground leading-relaxed">
              {selectedEntry.details.explanation}
            </div>
          </div>

          {/* Affected Paths */}
          <div>
            <div className="text-sm font-medium text-foreground mb-2">Affected Paths/Settings</div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3 space-y-1">
              {selectedEntry.affectedPaths.map((path, index) => (
                <div key={index} className="text-xs font-mono text-muted-foreground break-all">
                  {path}
                </div>
              ))}
            </div>
          </div>

          {/* Technical Summary */}
          <div>
            <div className="text-sm font-medium text-foreground mb-2">Technical Summary</div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3">
              <pre className="text-xs font-mono text-muted-foreground whitespace-pre-wrap">
                {JSON.stringify(selectedEntry.details.technical, null, 2)}
              </pre>
            </div>
          </div>

          {/* Safety Policy Result */}
          <div>
            <div className="text-sm font-medium text-foreground mb-2">Safety Policy</div>
            <div className="bg-secondary/50 border border-border rounded-lg p-3 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">User confirmation</span>
                <span className="text-foreground">
                  {selectedEntry.userConfirmation ? 'Required' : 'Not required'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Rollback available</span>
                <span className="text-foreground">
                  {selectedEntry.rollbackAvailable ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Result</span>
                <span className={selectedEntry.result === 'success' ? 'text-risk-safe' : 'text-risk-low'}>
                  {selectedEntry.result === 'success' ? 'Success' : 'Simulated'}
                </span>
              </div>
            </div>
          </div>

          {/* Rollback Button */}
          {selectedEntry.rollbackAvailable && (
            <button className="w-full py-3 bg-risk-medium/10 text-risk-medium border border-risk-medium/30 rounded-lg hover:bg-risk-medium/20 transition-all font-medium flex items-center justify-center gap-2">
              <RotateCcw className="w-4 h-4" />
              Rollback This Action
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
