import { Rocket, TrendingDown, RotateCcw } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';
import HealthScore from '../shared/HealthScore';

const startupApps = [
  {
    id: 1,
    name: 'Discord',
    publisher: 'Discord Inc.',
    impact: 'high' as const,
    impactScore: 8.2,
    status: 'enabled' as const,
    recommendation: 'Disable - not needed at startup',
    risk: 'safe' as const,
  },
  {
    id: 2,
    name: 'Spotify',
    publisher: 'Spotify AB',
    impact: 'high' as const,
    impactScore: 6.8,
    status: 'enabled' as const,
    recommendation: 'Disable - can launch manually',
    risk: 'safe' as const,
  },
  {
    id: 3,
    name: 'Steam',
    publisher: 'Valve Corporation',
    impact: 'medium' as const,
    impactScore: 4.2,
    status: 'enabled' as const,
    recommendation: 'Delay - reduce immediate impact',
    risk: 'safe' as const,
  },
  {
    id: 4,
    name: 'Windows Security Notification',
    publisher: 'Microsoft Corporation',
    impact: 'low' as const,
    impactScore: 0.8,
    status: 'enabled' as const,
    recommendation: 'Keep enabled - important for security',
    risk: 'safe' as const,
  },
  {
    id: 5,
    name: 'NVIDIA GeForce Experience',
    publisher: 'NVIDIA Corporation',
    impact: 'medium' as const,
    impactScore: 3.2,
    status: 'disabled' as const,
    recommendation: 'Already optimized',
    risk: 'safe' as const,
  },
];

export default function StartupApps() {
  const totalImpact = startupApps
    .filter(app => app.status === 'enabled')
    .reduce((sum, app) => sum + app.impactScore, 0);

  const potentialSavings = startupApps
    .filter(app => app.impact === 'high' || app.impact === 'medium')
    .filter(app => app.status === 'enabled')
    .reduce((sum, app) => sum + app.impactScore, 0);

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div>
        <h2>Startup Apps</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Reduce startup impact and improve boot time
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-5">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <div className="text-sm text-muted-foreground mb-1">Boot Time</div>
              <div className="text-2xl font-semibold text-foreground">18.2s</div>
            </div>
            <div className="p-2 rounded-lg bg-primary/10">
              <Rocket className="w-5 h-5 text-primary" />
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs text-risk-safe">
            <TrendingDown className="w-3 h-3" />
            <span>14s faster than before</span>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <div className="text-sm text-muted-foreground mb-1">Enabled Apps</div>
          <div className="text-2xl font-semibold text-foreground">
            {startupApps.filter(app => app.status === 'enabled').length}
          </div>
          <div className="text-xs text-muted-foreground mt-1">of {startupApps.length} total</div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <div className="text-sm text-muted-foreground mb-1">Current Impact</div>
          <div className="text-2xl font-semibold text-foreground">{totalImpact.toFixed(1)}s</div>
          <div className="text-xs text-muted-foreground mt-1">startup delay</div>
        </div>

        <div className="bg-card border border-border rounded-lg p-5">
          <div className="text-sm text-muted-foreground mb-1">Potential Savings</div>
          <div className="text-2xl font-semibold text-primary">{potentialSavings.toFixed(1)}s</div>
          <div className="text-xs text-muted-foreground mt-1">if optimized</div>
        </div>
      </div>

      {/* Recommended Safe Startup Changes */}
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20 rounded-lg p-6">
        <div className="flex items-start gap-4 mb-4">
          <HealthScore score={72} size="md" />
          <div className="flex-1">
            <h3 className="mb-2">Recommended Safe Startup Changes</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Disabling 3 high-impact startup applications will improve your boot time by approximately 8 seconds.
              All recommended changes can be safely reverted at any time.
            </p>
          </div>
        </div>
        <button className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
          Apply Recommended Changes
        </button>
      </div>

      {/* Startup Apps List */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Startup Applications</h3>

        <div className="space-y-3">
          {startupApps.map((app) => (
            <div
              key={app.id}
              className="bg-secondary/50 border border-border rounded-lg p-4 hover:border-primary/30 transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="font-medium text-foreground mb-1">{app.name}</div>
                  <div className="text-sm text-muted-foreground">{app.publisher}</div>
                </div>
                <div className="flex items-center gap-2">
                  <RiskBadge level={app.risk} size="sm" />
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${
                      app.status === 'enabled'
                        ? 'bg-risk-safe/10 text-risk-safe'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {app.status === 'enabled' ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-3">
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Impact</div>
                  <div className={`text-sm font-medium ${
                    app.impact === 'high' ? 'text-risk-high' :
                    app.impact === 'medium' ? 'text-risk-medium' :
                    'text-risk-safe'
                  }`}>
                    {app.impact.charAt(0).toUpperCase() + app.impact.slice(1)} ({app.impactScore}s)
                  </div>
                </div>
                <div className="col-span-2">
                  <div className="text-xs text-muted-foreground mb-1">Recommendation</div>
                  <div className="text-sm text-foreground">{app.recommendation}</div>
                </div>
              </div>

              <div className="flex gap-2 pt-3 border-t border-border">
                <button className="flex-1 px-4 py-2 bg-primary/10 text-primary rounded hover:bg-primary/20 transition-all text-sm">
                  Disable
                </button>
                <button className="flex-1 px-4 py-2 border border-border rounded hover:border-primary/30 transition-all text-sm">
                  Delay
                </button>
                <button className="px-4 py-2 border border-border rounded hover:border-primary/30 transition-all text-sm">
                  Ignore
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Rollback Notice */}
      <div className="bg-muted/30 border border-border rounded-lg p-4">
        <div className="flex items-start gap-3">
          <RotateCcw className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
          <div className="text-xs text-muted-foreground leading-relaxed">
            All startup changes are reversible. You can re-enable any application at any time from this screen
            or through the Restore Center.
          </div>
        </div>
      </div>
    </div>
  );
}
