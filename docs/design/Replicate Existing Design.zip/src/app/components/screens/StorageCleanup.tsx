import { HardDrive, Trash2, Archive, Eye } from 'lucide-react';
import RiskBadge from '../shared/RiskBadge';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const storageCategories = [
  {
    id: 1,
    name: 'Temporary Files',
    fileCount: 3247,
    size: '4.8 GB',
    sizeBytes: 5153960755,
    risk: 'safe' as const,
    description: 'Windows temporary files and system cache',
  },
  {
    id: 2,
    name: 'Browser Cache',
    fileCount: 1892,
    size: '2.1 GB',
    sizeBytes: 2254857830,
    risk: 'safe' as const,
    description: 'Cached files from web browsers',
  },
  {
    id: 3,
    name: 'Recycle Bin',
    fileCount: 127,
    size: '1.3 GB',
    sizeBytes: 1395864371,
    risk: 'safe' as const,
    description: 'Deleted files in Recycle Bin',
  },
  {
    id: 4,
    name: 'Old Logs',
    fileCount: 842,
    size: '892 MB',
    sizeBytes: 935329382,
    risk: 'safe' as const,
    description: 'Application and system log files',
  },
  {
    id: 5,
    name: 'Windows Update Cache',
    fileCount: 48,
    size: '3.2 GB',
    sizeBytes: 3435973836,
    risk: 'low' as const,
    description: 'Old Windows update installation files',
  },
  {
    id: 6,
    name: 'Quarantine',
    fileCount: 2,
    size: '2.4 MB',
    sizeBytes: 2516582,
    risk: 'safe' as const,
    description: 'Files moved to quarantine by PulseBoost AI',
  },
];

const chartData = storageCategories.map(cat => ({
  name: cat.name,
  value: cat.sizeBytes,
}));

const COLORS = ['#00d9ff', '#00ff88', '#ffb800', '#a78bfa', '#ff4757', '#8b92a8'];

export default function StorageCleanup() {
  const totalSize = storageCategories.reduce((sum, cat) => sum + cat.sizeBytes, 0);
  const totalFiles = storageCategories.reduce((sum, cat) => sum + cat.fileCount, 0);

  const formatBytes = (bytes: number) => {
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(1) + ' GB';
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(0) + ' MB';
    return (bytes / 1024).toFixed(0) + ' KB';
  };

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2>Storage Cleanup</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Safely clean files and recover disk space
          </p>
        </div>
        <button className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
          Run Storage Scan
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="mb-4">Storage Scan Summary</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total recoverable space</span>
              <span className="text-2xl font-semibold text-primary">{formatBytes(totalSize)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total files</span>
              <span className="text-xl font-semibold text-foreground">{totalFiles.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Categories</span>
              <span className="text-xl font-semibold text-foreground">{storageCategories.length}</span>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-border">
            <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Archive className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-foreground mb-1">Safe Cleanup Mode</div>
                  <div className="text-xs text-muted-foreground">
                    Files will be moved to quarantine first. You can restore them within 30 days before
                    permanent deletion.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="mb-4">Storage Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value: number) => formatBytes(value)}
                contentStyle={{
                  backgroundColor: '#13172b',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '8px',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {chartData.map((item, index) => (
              <div key={index} className="flex items-center gap-2 text-xs">
                <div
                  className="w-3 h-3 rounded"
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                />
                <span className="text-muted-foreground">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Cleanup Categories</h3>
        <div className="space-y-3">
          {storageCategories.map((category) => (
            <div
              key={category.id}
              className="bg-secondary/50 border border-border rounded-lg p-4 hover:border-primary/30 transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <HardDrive className="w-4 h-4 text-muted-foreground" />
                    <div className="font-medium text-foreground">{category.name}</div>
                  </div>
                  <div className="text-sm text-muted-foreground ml-7">{category.description}</div>
                </div>
                <RiskBadge level={category.risk} size="sm" />
              </div>

              <div className="grid grid-cols-3 gap-4 mb-3 ml-7">
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Size</div>
                  <div className="text-sm font-semibold text-primary">{category.size}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Files</div>
                  <div className="text-sm font-semibold text-foreground">
                    {category.fileCount.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-1">Risk Level</div>
                  <div className="text-sm font-semibold text-risk-safe">Safe</div>
                </div>
              </div>

              <div className="flex gap-2 ml-7 pt-3 border-t border-border">
                <button className="flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded hover:bg-primary/20 transition-all text-sm">
                  <Archive className="w-3 h-3" />
                  Move to Quarantine
                </button>
                <button className="flex items-center gap-2 px-4 py-2 border border-border rounded hover:border-primary/30 transition-all text-sm">
                  <Eye className="w-3 h-3" />
                  Preview Files
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Cleanup Actions */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="mb-4">Quick Actions</h3>
        <div className="grid grid-cols-3 gap-4">
          <button className="flex flex-col items-center gap-3 p-6 bg-secondary/50 border border-border rounded-lg hover:border-primary/30 transition-all">
            <div className="p-3 rounded-lg bg-primary/10">
              <Trash2 className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-foreground mb-1">Clean All Safe Items</div>
              <div className="text-xs text-muted-foreground">Move {formatBytes(totalSize)} to quarantine</div>
            </div>
          </button>

          <button className="flex flex-col items-center gap-3 p-6 bg-secondary/50 border border-border rounded-lg hover:border-primary/30 transition-all">
            <div className="p-3 rounded-lg bg-primary/10">
              <Eye className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-foreground mb-1">Preview All Changes</div>
              <div className="text-xs text-muted-foreground">Dry-run before cleanup</div>
            </div>
          </button>

          <button className="flex flex-col items-center gap-3 p-6 bg-secondary/50 border border-border rounded-lg hover:border-primary/30 transition-all">
            <div className="p-3 rounded-lg bg-primary/10">
              <Archive className="w-6 h-6 text-primary" />
            </div>
            <div className="text-center">
              <div className="text-sm font-medium text-foreground mb-1">View Quarantine</div>
              <div className="text-xs text-muted-foreground">Restore or delete files</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
