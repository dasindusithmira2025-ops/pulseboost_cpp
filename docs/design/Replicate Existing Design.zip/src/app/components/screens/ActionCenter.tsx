import { useState } from 'react';
import RiskBadge from '../shared/RiskBadge';
import { CheckCircle, XCircle, Shield, RotateCcw, FileText } from 'lucide-react';

type ActionCategory = 'Safe' | 'Manual' | 'Advanced' | 'High Risk';

const actions = [
  {
    id: 1,
    name: 'Disable Windows Search Indexing',
    category: 'Startup',
    benefit: 'Reduce disk I/O by 15%',
    risk: 'low' as const,
    dryRunStatus: 'passed' as const,
    backupRequired: true,
    rollbackAvailable: true,
    affectedItems: ['SearchIndexer.exe', 'WSearch service'],
    description: 'Disables Windows Search indexing service to reduce background disk activity. Search will still work but may be slower for initial queries.',
  },
  {
    id: 2,
    name: 'Clean temporary browser cache',
    category: 'Storage',
    benefit: 'Free 2.1 GB storage',
    risk: 'safe' as const,
    dryRunStatus: 'passed' as const,
    backupRequired: false,
    rollbackAvailable: true,
    affectedItems: ['Chrome Cache', 'Edge Cache', 'Firefox Cache'],
    description: 'Removes cached files from web browsers. This is completely safe and will not affect saved passwords or bookmarks.',
  },
  {
    id: 3,
    name: 'Adjust visual effects for performance',
    category: 'System',
    benefit: 'Improve UI responsiveness',
    risk: 'safe' as const,
    dryRunStatus: 'passed' as const,
    backupRequired: true,
    rollbackAvailable: true,
    affectedItems: ['SystemPropertiesPerformance'],
    description: 'Reduces Windows visual effects to improve system responsiveness. Changes can be reverted at any time.',
  },
  {
    id: 4,
    name: 'Modify registry power settings',
    category: 'Advanced',
    benefit: 'Optimize power management',
    risk: 'medium' as const,
    dryRunStatus: 'pending' as const,
    backupRequired: true,
    rollbackAvailable: true,
    affectedItems: ['HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Power'],
    description: 'Adjusts registry settings for power management. Dry-run required before applying.',
  },
  {
    id: 5,
    name: 'Disable system telemetry services',
    category: 'Privacy',
    benefit: 'Reduce background activity',
    risk: 'high' as const,
    dryRunStatus: 'pending' as const,
    backupRequired: true,
    rollbackAvailable: true,
    affectedItems: ['DiagTrack', 'dmwappushservice'],
    description: 'Disables Windows telemetry services. This action requires manual review and restore point creation.',
  },
];

export default function ActionCenter() {
  const [activeFilter, setActiveFilter] = useState<ActionCategory>('Safe');
  const [selectedAction, setSelectedAction] = useState(actions[0]);

  const filteredActions = actions.filter((action) => {
    if (activeFilter === 'Safe') return action.risk === 'safe';
    if (activeFilter === 'Manual') return action.risk === 'low';
    if (activeFilter === 'Advanced') return action.risk === 'medium';
    if (activeFilter === 'High Risk') return action.risk === 'high';
    return true;
  });

  return (
    <div className="h-full flex">
      {/* Left Panel - Actions List */}
      <div className="flex-1 p-8 overflow-auto border-r border-border">
        <div className="mb-6">
          <h2>Action Center</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Review and execute optimizations safely
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-6">
          {(['Safe', 'Manual', 'Advanced', 'High Risk'] as ActionCategory[]).map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-4 py-2 rounded-lg text-sm transition-all ${
                activeFilter === filter
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary hover:bg-secondary/70'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Actions List */}
        <div className="space-y-3">
          {filteredActions.map((action) => (
            <div
              key={action.id}
              onClick={() => setSelectedAction(action)}
              className={`bg-card border rounded-lg p-4 cursor-pointer transition-all ${
                selectedAction.id === action.id
                  ? 'border-primary shadow-lg shadow-primary/20'
                  : 'border-border hover:border-primary/30'
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="font-medium text-foreground mb-1">{action.name}</div>
                  <div className="text-sm text-muted-foreground">{action.benefit}</div>
                </div>
                <RiskBadge level={action.risk} size="sm" />
              </div>

              <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  {action.dryRunStatus === 'passed' ? (
                    <CheckCircle className="w-3 h-3 text-risk-safe" />
                  ) : (
                    <XCircle className="w-3 h-3 text-muted-foreground" />
                  )}
                  <span>Dry-run {action.dryRunStatus}</span>
                </div>
                {action.rollbackAvailable && (
                  <div className="flex items-center gap-1">
                    <RotateCcw className="w-3 h-3" />
                    <span>Rollback available</span>
                  </div>
                )}
                {action.backupRequired && (
                  <div className="flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    <span>Backup required</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2 mt-3">
                <button className="text-xs px-3 py-1.5 bg-primary/10 text-primary rounded hover:bg-primary/20 transition-all">
                  Dry Run
                </button>
                <button className="text-xs px-3 py-1.5 border border-border rounded hover:border-primary/30 transition-all">
                  Review
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Panel - Action Details */}
      <div className="w-[480px] p-8 bg-card/50 backdrop-blur-sm overflow-auto">
        <div className="space-y-6">
          <div>
            <div className="flex items-start justify-between mb-3">
              <h3>{selectedAction.name}</h3>
              <RiskBadge level={selectedAction.risk} />
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {selectedAction.description}
            </p>
          </div>

          {/* Safety Information */}
          <div className="bg-secondary/50 border border-border rounded-lg p-4">
            <div className="text-sm font-medium text-foreground mb-3">Safety Policy Result</div>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Dry-run status</span>
                <span className="flex items-center gap-1 text-risk-safe">
                  <CheckCircle className="w-3 h-3" />
                  Passed
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Rollback available</span>
                <span className="text-foreground">
                  {selectedAction.rollbackAvailable ? 'Yes' : 'No'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Backup required</span>
                <span className="text-foreground">
                  {selectedAction.backupRequired ? 'Yes' : 'No'}
                </span>
              </div>
            </div>
          </div>

          {/* Affected Items */}
          <div>
            <div className="text-sm font-medium text-foreground mb-3">
              Files/Settings/Processes Affected
            </div>
            <div className="bg-secondary/50 border border-border rounded-lg p-4">
              <div className="space-y-2">
                {selectedAction.affectedItems.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 text-sm text-muted-foreground font-mono"
                  >
                    <FileText className="w-3 h-3 flex-shrink-0" />
                    <span className="break-all">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Confirmation Gate */}
          <div className="bg-gradient-to-r from-primary/10 to-transparent border border-primary/20 rounded-lg p-4">
            <div className="flex items-start gap-3 mb-4">
              <Shield className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <div className="text-sm font-medium text-foreground mb-1">Confirmation Gate</div>
                <div className="text-xs text-muted-foreground">
                  This action requires your explicit approval before execution
                </div>
              </div>
            </div>

            {/* Create Restore Point Toggle */}
            <div className="flex items-center justify-between mb-4 p-3 bg-card rounded-lg">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-foreground">Create Restore Point</span>
              </div>
              <div className="w-11 h-6 bg-primary rounded-full relative">
                <div className="w-5 h-5 bg-white rounded-full absolute right-0.5 top-0.5" />
              </div>
            </div>

            {/* Apply Button */}
            <button
              disabled={selectedAction.dryRunStatus !== 'passed'}
              className={`w-full py-3 rounded-lg font-medium transition-all ${
                selectedAction.dryRunStatus === 'passed'
                  ? 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20'
                  : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
            >
              {selectedAction.dryRunStatus === 'passed' ? 'Apply Action' : 'Dry-run Required'}
            </button>

            {selectedAction.dryRunStatus !== 'passed' && (
              <p className="text-xs text-muted-foreground mt-2 text-center">
                Run a dry-run simulation before applying this action
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
