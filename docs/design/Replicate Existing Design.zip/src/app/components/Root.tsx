import { Outlet, NavLink } from 'react-router';
import {
  LayoutDashboard,
  Zap,
  Sparkles,
  BarChart3,
  FileText,
  RotateCcw,
  Activity,
  Rocket,
  HardDrive,
  Wifi,
  Settings as SettingsIcon,
  Shield
} from 'lucide-react';

const navigation = [
  { name: 'Overview', path: '/', icon: LayoutDashboard },
  { name: 'Action Center', path: '/action-center', icon: Zap },
  { name: 'AI Advisor', path: '/ai-advisor', icon: Sparkles },
  { name: 'Before / After Proof', path: '/before-after', icon: BarChart3 },
  { name: 'Audit Log', path: '/audit-log', icon: FileText },
  { name: 'Restore Center', path: '/restore-center', icon: RotateCcw },
  { name: 'Processes', path: '/processes', icon: Activity },
  { name: 'Startup Apps', path: '/startup-apps', icon: Rocket },
  { name: 'Storage Cleanup', path: '/storage-cleanup', icon: HardDrive },
  { name: 'Network Tools', path: '/network-tools', icon: Wifi },
  { name: 'Settings', path: '/settings', icon: SettingsIcon },
];

export default function Root() {
  return (
    <div className="h-screen w-screen flex flex-col bg-background overflow-hidden">
      {/* Top Status Bar */}
      <div className="h-14 border-b border-border bg-card/50 backdrop-blur-sm flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-primary" />
          <h1 className="text-foreground tracking-tight">PulseBoost AI</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="w-2 h-2 rounded-full bg-risk-safe animate-pulse" />
            <span>System Protected</span>
          </div>
          <div className="text-sm text-muted-foreground">
            Last scan: 2 minutes ago
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 border-r border-sidebar-border bg-sidebar flex flex-col">
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navigation.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.path === '/'}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                    isActive
                      ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-lg shadow-primary/20'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <item.icon className={`w-5 h-5 ${isActive ? '' : 'opacity-70'}`} />
                    <span className="text-sm">{item.name}</span>
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <div className="p-4 border-t border-sidebar-border">
            <div className="bg-sidebar-accent rounded-lg p-3 space-y-1">
              <div className="text-xs text-muted-foreground">Version</div>
              <div className="text-sm text-sidebar-foreground">2.5.0 Pro</div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
