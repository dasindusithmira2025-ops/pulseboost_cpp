interface HealthScoreProps {
  score: number;
  size?: 'md' | 'lg';
}

export default function HealthScore({ score, size = 'lg' }: HealthScoreProps) {
  const radius = size === 'lg' ? 70 : 50;
  const stroke = size === 'lg' ? 8 : 6;
  const normalizedRadius = radius - stroke / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const getColor = (score: number) => {
    if (score >= 90) return '#00ff88';
    if (score >= 70) return '#00d9ff';
    if (score >= 50) return '#ffb800';
    return '#ff4757';
  };

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg
        height={radius * 2}
        width={radius * 2}
        className="transform -rotate-90"
      >
        <circle
          stroke="rgba(255, 255, 255, 0.05)"
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        <circle
          stroke={getColor(score)}
          fill="transparent"
          strokeWidth={stroke}
          strokeDasharray={circumference + ' ' + circumference}
          style={{ strokeDashoffset, transition: 'stroke-dashoffset 0.5s ease' }}
          strokeLinecap="round"
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className={`${size === 'lg' ? 'text-4xl' : 'text-2xl'} font-bold text-foreground`}>
          {score}
        </div>
        <div className="text-xs text-muted-foreground">Health Score</div>
      </div>
    </div>
  );
}
