import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
  iconColor?: string;
}

export default function MetricCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  iconColor = 'text-primary'
}: MetricCardProps) {
  const trendColors = {
    up: 'text-risk-high',
    down: 'text-risk-safe',
    neutral: 'text-muted-foreground'
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 hover:border-primary/30 transition-all">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="text-sm text-muted-foreground mb-1">{title}</div>
          <div className="text-2xl font-semibold text-foreground mb-1">{value}</div>
          {subtitle && (
            <div className={`text-xs ${trend ? trendColors[trend] : 'text-muted-foreground'}`}>
              {subtitle}
            </div>
          )}
        </div>
        <div className={`p-2.5 rounded-lg bg-primary/10 ${iconColor}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}
