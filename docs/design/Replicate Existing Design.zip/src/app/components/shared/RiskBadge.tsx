type RiskLevel = 'safe' | 'low' | 'medium' | 'high' | 'manual';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md';
}

const riskConfig: Record<RiskLevel, { label: string; color: string; bgColor: string }> = {
  safe: { label: 'Safe', color: 'text-risk-safe', bgColor: 'bg-risk-safe/10' },
  low: { label: 'Low Risk', color: 'text-risk-low', bgColor: 'bg-risk-low/10' },
  medium: { label: 'Medium Risk', color: 'text-risk-medium', bgColor: 'bg-risk-medium/10' },
  high: { label: 'High Risk', color: 'text-risk-high', bgColor: 'bg-risk-high/10' },
  manual: { label: 'Manual Review', color: 'text-risk-manual', bgColor: 'bg-risk-manual/10' },
};

export default function RiskBadge({ level, size = 'md' }: RiskBadgeProps) {
  const config = riskConfig[level];
  const sizeClasses = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-sm px-3 py-1';

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full ${config.bgColor} ${config.color} ${sizeClasses} font-medium`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.color.replace('text-', 'bg-')}`} />
      {config.label}
    </span>
  );
}
