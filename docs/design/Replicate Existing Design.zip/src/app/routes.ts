import { createBrowserRouter } from "react-router";
import Root from "./components/Root";
import Overview from "./components/screens/Overview";
import ActionCenter from "./components/screens/ActionCenter";
import AIAdvisor from "./components/screens/AIAdvisor";
import BeforeAfterProof from "./components/screens/BeforeAfterProof";
import AuditLog from "./components/screens/AuditLog";
import RestoreCenter from "./components/screens/RestoreCenter";
import Processes from "./components/screens/Processes";
import StartupApps from "./components/screens/StartupApps";
import StorageCleanup from "./components/screens/StorageCleanup";
import NetworkTools from "./components/screens/NetworkTools";
import Settings from "./components/screens/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Overview },
      { path: "action-center", Component: ActionCenter },
      { path: "ai-advisor", Component: AIAdvisor },
      { path: "before-after", Component: BeforeAfterProof },
      { path: "audit-log", Component: AuditLog },
      { path: "restore-center", Component: RestoreCenter },
      { path: "processes", Component: Processes },
      { path: "startup-apps", Component: StartupApps },
      { path: "storage-cleanup", Component: StorageCleanup },
      { path: "network-tools", Component: NetworkTools },
      { path: "settings", Component: Settings },
    ],
  },
]);
