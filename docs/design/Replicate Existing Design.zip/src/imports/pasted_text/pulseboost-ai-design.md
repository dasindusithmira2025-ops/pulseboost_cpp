Design a premium Windows desktop application UI for “PulseBoost AI”, a serious AI-assisted PC optimizer and system safety tool.

This is not a cheap “RAM booster” app. It must feel like a trustworthy, investor-ready, enterprise-grade Windows utility for diagnostics, safe optimization, rollback, audit logs, and before/after proof.

Target platform:
Desktop app UI, 1440x900 layout, designed so developers can later rebuild it in Qt/QML. Do not make it look like a mobile app. Use a professional Windows desktop layout with a left sidebar, top status bar, main content area, cards, tables, dialogs, graphs, and safety confirmation panels.

Brand personality:
Premium, futuristic, trustworthy, calm, technical, clean, powerful, not childish, not flashy, not scammy. The UI should feel like a mix of Microsoft Defender, Windows Task Manager, Linear, Vercel, Raycast, and a premium cybersecurity dashboard.

Visual style:
Use a dark theme by default.
Background: deep navy / near-black graphite.
Primary accent: electric cyan or soft blue.
Secondary accents: green for safe, amber for medium risk, red for high risk.
Use glassmorphism very lightly, not too much.
Use soft shadows, rounded cards, clean spacing, thin borders, subtle gradients, and professional typography.
Use clear iconography for CPU, RAM, disk, startup, restore, audit, AI, shield, warning, and rollback.
Make the interface feel modern, expensive, and production-ready.

Core product concept:
PulseBoost AI scans the PC, explains what is slowing it down, recommends safe optimizations, performs dry-runs first, requires confirmation for risky actions, creates restore/undo options, logs every system-changing action, and shows before/after proof.

Important safety philosophy:
Every action must visibly show:
- Risk level
- Dry-run result
- What will change
- Backup or restore availability
- Confirmation requirement
- Whether rollback is possible
- Audit log entry after execution

Main navigation sidebar:
1. Overview
2. Action Center
3. AI Advisor
4. Before / After Proof
5. Audit Log
6. Restore Center
7. Processes
8. Startup Apps
9. Storage Cleanup
10. Network Tools
11. Settings

Create these screens in one cohesive design system:

SCREEN 1: Overview Dashboard
Purpose: show system health at a glance.
Layout:
- Top bar with app name “PulseBoost AI”, system status, last scan time, and a “Run Safe Scan” primary button.
- Hero card: “PC Health Score” with circular score indicator.
- Four metric cards: CPU Pressure, Memory Pressure, Disk Usage, Startup Impact.
- “Recommended Safe Actions” card with 3 suggested actions and risk badges.
- “Before / After Snapshot” small chart comparing current vs last optimized state.
- “Safety Status” card showing Restore Point Available, Audit Logging Enabled, AI Advisory Mode Enabled.
- Right-side AI summary panel saying what the app found in plain language.

SCREEN 2: Action Center
Purpose: central place to review and execute optimizations safely.
Layout:
- Header: “Action Center”
- Tabs or filters: Safe, Manual, Advanced, High Risk.
- Table/list of optimization actions.
Each action row/card must show:
  - Action name
  - Category
  - Expected benefit
  - Risk badge
  - Dry-run status
  - Backup required indicator
  - Rollback availability
  - Buttons: “Dry Run”, “Review”, “Apply”
- Add a large selected-action detail panel on the right:
  - What this action will do
  - Files/settings/processes affected
  - Safety policy result
  - Confirmation gate
  - “Create Restore Point” toggle
  - “Apply Action” button disabled until dry-run passes
Make this screen extremely trustworthy and clear.

SCREEN 3: AI Advisor
Purpose: AI recommends but does not silently execute risky actions.
Layout:
- Chat-style interface on the left.
- Recommendation cards on the right.
- AI message example: “I found 4 low-risk cleanup opportunities and 2 advanced actions that require manual review.”
- Each recommendation card must include:
  - Reason
  - Confidence
  - Risk
  - Evidence
  - Button: “Prepare Dry Run”
- Add a visible banner: “AI Advisory Mode: AI can recommend actions, but high-risk actions require your confirmation.”
- Avoid making the AI look like a chatbot toy. Make it feel like a professional diagnostic assistant.

SCREEN 4: Before / After Proof
Purpose: prove the optimizer actually changed something.
Layout:
- Header: “Before / After Proof Report”
- Comparison cards for:
  - Recoverable storage
  - Startup items
  - Memory pressure
  - Background processes
  - Disk usage
- Use side-by-side “Before” and “After” columns.
- Add line/bar charts.
- Include “Export Report” button.
- Include a timeline showing Scan → Dry Run → Restore Point → Apply → Verified Result.
- Make it investor-demo ready.

SCREEN 5: Audit Log
Purpose: show transparency and trust.
Layout:
- Searchable table with columns:
  - Time
  - Action
  - Risk
  - Result
  - Rollback Available
  - User Confirmation
  - Details
- Add filters: Today, This Week, High Risk, Rollback Available, Failed Actions.
- Right-side detail drawer for selected audit entry:
  - JSON-style technical summary
  - Human-readable explanation
  - Affected paths/settings
  - Safety policy result
Make it look serious and compliance-ready.

SCREEN 6: Restore Center
Purpose: undo/restore safety hub.
Layout:
- Cards for:
  - System Restore Points
  - Quarantined Files
  - Reversible Tweaks
  - Rollback-capable Actions
- Timeline of restore options.
- Each restore item must show:
  - Created time
  - Related action
  - Restore type
  - Risk
  - Button: “Restore”
- Include warning dialog design for restore confirmation.
- Make user feel safe that changes are reversible.

SCREEN 7: Processes
Purpose: inspect heavy processes but avoid unsafe killing.
Layout:
- Process table with CPU, RAM, disk, publisher, path, safety status.
- “Analyze Process” button.
- “End Process” must be shown as high-risk and require confirmation.
- Include AI explanation panel: “Why this process is using resources.”
- Do not make process killing look casual.

SCREEN 8: Startup Apps
Purpose: reduce startup impact.
Layout:
- Startup impact score.
- List of startup apps with publisher, impact, recommendation.
- Buttons: Disable, Delay, Ignore.
- Show safety notes and rollback option.
- Include “Recommended Safe Startup Changes” section.

SCREEN 9: Storage Cleanup
Purpose: clean files safely.
Layout:
- Storage scan summary.
- Categories:
  - Temporary files
  - Browser cache
  - Recycle bin
  - Old logs
  - Quarantine
- Each category must show file count, size, risk, and preview option.
- Use “Move to Quarantine” as the default, not permanent delete.
- Include dry-run preview before cleanup.

SCREEN 10: Network Tools
Purpose: advanced network diagnostics only.
Layout:
- Network health panel.
- DNS, latency, adapter, TCP status cards.
- Mark global network changes as “Advanced / Manual Review Required”.
- Include backup/revert requirement.
- Do not make network reset a one-click casual action.

SCREEN 11: Settings
Purpose: control safety and privacy.
Layout:
- AI mode: Local only / Cloud optional / Disabled.
- Safety gates: Require confirmation for medium/high risk.
- Audit logging toggle.
- Quarantine duration.
- Restore point behavior.
- Theme controls.
- Privacy section: local telemetry, no selling data, no silent system changes.

Components to design:
- Risk badge system: Safe, Low, Medium, High, Manual
- Confirmation modal
- Dry-run result modal
- Restore confirmation dialog
- Audit detail drawer
- AI recommendation card
- Metric cards
- Health score ring
- Before/after comparison chart
- Timeline component
- Sidebar navigation
- Status bar

Important UX rules:
- Never show dangerous actions as casual one-click buttons.
- High-risk actions must look serious and require review.
- The product should build trust through explanation, proof, and rollback.
- Use plain English for normal users, but provide technical details in expandable panels.
- Keep the layout clean, spacious, and premium.
- Avoid clutter, neon overload, fake gaming style, or scammy optimizer language.

Content tone:
Use phrases like:
- “Safe scan completed”
- “Dry-run required”
- “Rollback available”
- “Restore point recommended”
- “AI recommendation prepared”
- “Manual review required”
- “Before / after proof”
Avoid phrases like:
- “300% faster”
- “Instant RAM boost”
- “Magic cleanup”
- “One-click miracle”

Generate a cohesive multi-screen UI design system with polished desktop screens, consistent spacing, premium dark theme, professional cards, real-looking data tables, safety-first flows, and investor-demo quality.